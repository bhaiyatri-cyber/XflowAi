package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "schedules")
data class Schedule(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val subject: String,
    val description: String,
    val isDurationMode: Boolean,
    val durationMinutes: Int, // for duration mode
    val startTimeStr: String, // for exact time mode
    val endTimeStr: String,
    val isOnlineMode: Boolean,
    val selectedAppPackage: String?,
    val isActive: Boolean = true,
    val elapsedSeconds: Int = 0,
    val isRunning: Boolean = false,
    val isFromStudyPlan: Boolean = false,
    val studyPlanId: Int = 0,
    val creationDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistorySession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val scheduleId: Int,
    val subject: String,
    val mode: String, // Duration or Exact
    val date: Long,
    val timeStudiedSeconds: Int,
    val completionPercentage: Int,
    val status: String // Completed, Partial, Missed
)

@Entity(tableName = "study_plans")
data class StudyPlan(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val recurrenceDays: Int, // -1 for always, or number of days
    val createdAt: Long,
    val lastGeneratedDay: Long
)

@Entity(tableName = "study_plan_items")
data class StudyPlanItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val planId: Int,
    val subject: String,
    val description: String,
    val startTimeStr: String,
    val endTimeStr: String,
    val isOnlineMode: Boolean,
    val selectedAppPackage: String?
)

@Dao
interface XFlowDao {
    @Query("SELECT * FROM schedules WHERE isActive = 1")
    fun getActiveSchedules(): Flow<List<Schedule>>

    @Query("SELECT * FROM schedules WHERE isActive = 1")
    suspend fun getActiveSchedulesSync(): List<Schedule>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSchedule(schedule: Schedule): Long

    @Query("UPDATE schedules SET isActive = 0 WHERE id = :id")
    suspend fun deactivateSchedule(id: Int)
    
    @Query("SELECT * FROM schedules WHERE id = :id")
    suspend fun getScheduleById(id: Int): Schedule?

    @Query("UPDATE schedules SET elapsedSeconds = :elapsed, isRunning = :running WHERE id = :id")
    suspend fun updateScheduleProgress(id: Int, elapsed: Int, running: Boolean)

    @Query("SELECT * FROM history ORDER BY date DESC")
    fun getAllHistory(): Flow<List<HistorySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(session: HistorySession)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyPlan(plan: StudyPlan): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStudyPlanItems(items: List<StudyPlanItem>)

    @Query("SELECT * FROM study_plans")
    suspend fun getAllStudyPlans(): List<StudyPlan>

    @Query("SELECT * FROM study_plan_items WHERE planId = :planId")
    suspend fun getStudyPlanItems(planId: Int): List<StudyPlanItem>

    @Query("UPDATE study_plans SET lastGeneratedDay = :day WHERE id = :planId")
    suspend fun updateStudyPlanGeneratedDay(planId: Int, day: Long)
}

@Database(entities = [Schedule::class, HistorySession::class, StudyPlan::class, StudyPlanItem::class], version = 3, exportSchema = false)
abstract class XFlowDatabase : RoomDatabase() {
    abstract fun dao(): XFlowDao
    
    companion object {
        @Volatile
        private var INSTANCE: XFlowDatabase? = null

        fun getDatabase(context: android.content.Context): XFlowDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    XFlowDatabase::class.java,
                    "xflow-db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
