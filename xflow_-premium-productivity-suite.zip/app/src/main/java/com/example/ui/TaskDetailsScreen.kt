package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaskDetailsScreen(id: Int, viewModel: XFlowViewModel, onBack: () -> Unit) {
    val schedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val schedule = schedules.find { it.id == id }

    var showCompleteDialog by remember { mutableStateOf(false) }

    if (schedule == null) {
        LaunchedEffect(Unit) { onBack() }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Task Details", color = XFlowTextPrimary) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(XFlowSurface)
                    .padding(24.dp)
            ) {
                Column {
                    Text(schedule.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(schedule.description, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyLarge)
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = XFlowSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))
                    DetailRow("Mode", if (schedule.isDurationMode) "Duration" else "Exact Time")
                    if (schedule.isDurationMode) {
                        DetailRow("Duration", "${schedule.durationMinutes} min")
                    } else {
                        DetailRow("Time", "${schedule.startTimeStr} - ${schedule.endTimeStr}")
                    }
                    DetailRow("Tracking", if (schedule.isOnlineMode) "Online (${schedule.selectedAppPackage})" else "Offline")
                    DetailRow("Elapsed", String.format("%02d:%02d:%02d", schedule.elapsedSeconds / 3600, (schedule.elapsedSeconds % 3600) / 60, schedule.elapsedSeconds % 60))
                    DetailRow("Status", if (schedule.isRunning) "Running" else "Waiting")
                }
            }
            
            Spacer(modifier = Modifier.weight(1f))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Button(
                    onClick = { showCompleteDialog = true },
                    modifier = Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = XFlowSupport, contentColor = XFlowBackground)
                ) {
                    Text("Complete Manually", fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showCompleteDialog) {
        AlertDialog(
            onDismissRequest = { showCompleteDialog = false },
            title = { Text("Complete Session") },
            text = { Text("Are you sure you want to complete this session? It will be moved to History.") },
            confirmButton = {
                TextButton(onClick = {
                    val targetTime = if (schedule.isDurationMode) {
                        schedule.durationMinutes * 60
                    } else {
                        try {
                            val startParts = schedule.startTimeStr.split(":")
                            val endParts = schedule.endTimeStr.split(":")
                            val startMins = startParts[0].toInt() * 60 + startParts[1].toInt()
                            val endMins = endParts[0].toInt() * 60 + endParts[1].toInt()
                            val diff = endMins - startMins
                            if (diff > 0) diff * 60 else 60 * 60 // fallback 1h
                        } catch (e: Exception) {
                            60 * 60 // fallback 1h
                        }
                    }
                    val percentage = if (targetTime > 0) {
                        ((schedule.elapsedSeconds.toFloat() / targetTime.toFloat()) * 100).toInt().coerceIn(0, 100)
                    } else {
                        100
                    }
                    val status = if (percentage >= 100) "Completed" else "Partial ($percentage%)"
                    
                    viewModel.completeSession(schedule, schedule.elapsedSeconds, percentage, status)
                    showCompleteDialog = false
                    onBack()
                }) {
                    Text("Complete", color = XFlowAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCompleteDialog = false }) {
                    Text("Cancel", color = XFlowTextSecondary)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
}

@Composable
fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = XFlowTextSecondary)
        Text(value, color = XFlowTextPrimary, fontWeight = FontWeight.Medium)
    }
}
