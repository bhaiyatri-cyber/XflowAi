package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.data.HistorySession
import com.example.data.Schedule
import com.example.data.StudyPlan
import com.example.data.StudyPlanItem
import com.example.data.XFlowDatabase
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Calendar

class XFlowViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("xflow_prefs", android.content.Context.MODE_PRIVATE)
    
    private val _isPremium = kotlinx.coroutines.flow.MutableStateFlow(prefs.getBoolean("is_premium", false))
    val isPremium: StateFlow<Boolean> = _isPremium
    
    fun activatePremium(code: String): Boolean {
        if (code.equals("Nitesh", ignoreCase = true)) {
            prefs.edit().putBoolean("is_premium", true).apply()
            _isPremium.value = true
            return true
        }
        return false
    }

    private val db = XFlowDatabase.getDatabase(application)
    
    val activeSchedules: StateFlow<List<Schedule>> = db.dao().getActiveSchedules()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        
    val history: StateFlow<List<HistorySession>> = db.dao().getAllHistory()
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    val todayHours: StateFlow<Float> = history.map { list ->
        val todayStart = System.currentTimeMillis() - (24 * 60 * 60 * 1000)
        list.filter { it.date > todayStart }.sumOf { it.timeStudiedSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    val lifetimeHours: StateFlow<Float> = history.map { list ->
        list.sumOf { it.timeStudiedSeconds } / 3600f
    }.stateIn(viewModelScope, SharingStarted.Lazily, 0f)

    init {
        checkAndRolloverStudyPlans()
    }

    private fun getCurrentDay(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    private fun checkAndRolloverStudyPlans() {
        viewModelScope.launch {
            val plans = db.dao().getAllStudyPlans()
            val currentDayMillis = getCurrentDay()
            
            var generatedAny = false
            for (plan in plans) {
                if (plan.lastGeneratedDay < currentDayMillis) {
                    // Check recurrence
                    val daysSinceCreation = (currentDayMillis - plan.createdAt) / 86400000
                    if (plan.recurrenceDays == -1 || daysSinceCreation <= plan.recurrenceDays) {
                        // Generate schedules for today
                        val items = db.dao().getStudyPlanItems(plan.id)
                        for (item in items) {
                            val schedule = Schedule(
                                subject = item.subject,
                                description = item.description,
                                isDurationMode = false,
                                durationMinutes = 0,
                                startTimeStr = item.startTimeStr,
                                endTimeStr = item.endTimeStr,
                                isOnlineMode = item.isOnlineMode,
                                selectedAppPackage = item.selectedAppPackage,
                                isActive = true,
                                isFromStudyPlan = true,
                                studyPlanId = plan.id,
                                creationDate = System.currentTimeMillis()
                            )
                            db.dao().insertSchedule(schedule)
                        }
                        db.dao().updateStudyPlanGeneratedDay(plan.id, currentDayMillis)
                        generatedAny = true
                    }
                }
            }
            
            // Also archive yesterday's unfinished schedules
            if (generatedAny) {
                val activeSchedules = db.dao().getActiveSchedulesSync()
                for (schedule in activeSchedules) {
                    if (schedule.creationDate < currentDayMillis && schedule.isFromStudyPlan) {
                        // Mark as missed or partial
                        db.dao().insertHistory(
                            HistorySession(
                                scheduleId = schedule.id,
                                subject = schedule.subject,
                                mode = "Exact Time",
                                date = schedule.creationDate,
                                timeStudiedSeconds = schedule.elapsedSeconds,
                                completionPercentage = if (schedule.elapsedSeconds > 0) 50 else 0,
                                status = if (schedule.elapsedSeconds > 0) "Partial" else "Missed"
                            )
                        )
                        db.dao().deactivateSchedule(schedule.id)
                    }
                }
            }
        }
    }

    fun saveStudyPlan(recurrenceDays: Int, items: List<StudyPlanItem>) {
        viewModelScope.launch {
            val plan = StudyPlan(
                recurrenceDays = recurrenceDays,
                createdAt = System.currentTimeMillis(),
                lastGeneratedDay = 0 // force generation immediately
            )
            val planId = db.dao().insertStudyPlan(plan).toInt()
            
            val updatedItems = items.map { it.copy(planId = planId) }
            db.dao().insertStudyPlanItems(updatedItems)
            
            checkAndRolloverStudyPlans()
        }
    }

    fun addSchedule(schedule: Schedule, context: android.content.Context) {
        viewModelScope.launch {
            val id = db.dao().insertSchedule(schedule)
            // start service for tracking
            val intent = android.content.Intent(context, com.example.service.TrackingService::class.java)
            intent.putExtra("schedule_id", id.toInt())
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }

    fun completeSession(schedule: Schedule, secondsStudied: Int, percent: Int, status: String) {
        viewModelScope.launch {
            db.dao().insertHistory(
                HistorySession(
                    scheduleId = schedule.id,
                    subject = schedule.subject,
                    mode = if (schedule.isDurationMode) "Duration" else "Exact Time",
                    date = System.currentTimeMillis(),
                    timeStudiedSeconds = secondsStudied,
                    completionPercentage = percent,
                    status = status
                )
            )
            db.dao().deactivateSchedule(schedule.id)
        }
    }
}
