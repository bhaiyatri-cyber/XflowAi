package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.Schedule
import com.example.ui.theme.*
import com.example.utils.PermissionUtils
import androidx.compose.animation.core.animateFloat
import android.widget.Toast

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: XFlowViewModel,
    onNavigateToSettings: () -> Unit,
    onNavigateToCreate: () -> Unit,
    onNavigateToTask: (Int) -> Unit,
    onNavigateToProgress: () -> Unit,
    onNavigateToPermissions: () -> Unit,
    onNavigateToStudyPlan: () -> Unit
) {
    val activeSchedules by viewModel.activeSchedules.collectAsStateWithLifecycle()
    val todayHours by viewModel.todayHours.collectAsStateWithLifecycle()
    val lifetimeHours by viewModel.lifetimeHours.collectAsStateWithLifecycle()
    val isPremium by viewModel.isPremium.collectAsStateWithLifecycle()
    
    val context = LocalContext.current
    var showPermissionDialog by remember { mutableStateOf(false) }
    var showPremiumDialog by remember { mutableStateOf(false) }
    var premiumCode by remember { mutableStateOf("") }

    val handleCreateClick = {
        if (PermissionUtils.hasAllPermissions(context)) {
            onNavigateToCreate()
        } else {
            showPermissionDialog = true
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("XFlow", color = XFlowAccent, fontWeight = FontWeight.Bold) },
                actions = {
                    PremiumStudyPlanButton(isPremium = isPremium) {
                        if (isPremium) {
                            if (PermissionUtils.hasAllPermissions(context)) {
                                onNavigateToStudyPlan()
                            } else {
                                showPermissionDialog = true
                            }
                        } else {
                            showPremiumDialog = true
                        }
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings", tint = XFlowTextPrimary)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = XFlowBackground)
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = handleCreateClick,
                containerColor = XFlowAccent,
                contentColor = XFlowBackground
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Schedule")
            }
        },
        containerColor = XFlowBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatCard(
                    title = "Today",
                    value = String.format("%.1fh", todayHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
                StatCard(
                    title = "Lifetime",
                    value = String.format("%.1fh", lifetimeHours),
                    modifier = Modifier.weight(1f).clickable { onNavigateToProgress() }
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("Active Schedules", color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(16.dp))

            if (activeSchedules.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("No active schedules", color = XFlowTextSecondary)
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = handleCreateClick,
                            colors = ButtonDefaults.buttonColors(containerColor = XFlowSurfaceVariant, contentColor = XFlowAccent)
                        ) {
                            Text("Create one now")
                        }
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(activeSchedules) { schedule ->
                        ScheduleCard(schedule, onClick = { onNavigateToTask(schedule.id) })
                    }
                    item { Spacer(modifier = Modifier.height(80.dp)) }
                }
            }
        }
    }

    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("Permissions Required") },
            text = { Text("You must grant all required permissions before creating a schedule.") },
            confirmButton = {
                TextButton(onClick = {
                    showPermissionDialog = false
                    onNavigateToPermissions()
                }) {
                    Text("Go to Settings", color = XFlowAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPermissionDialog = false }) {
                    Text("Cancel", color = XFlowTextSecondary)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }

    if (showPremiumDialog) {
        AlertDialog(
            onDismissRequest = { showPremiumDialog = false },
            title = { Text("Premium Feature") },
            text = {
                Column {
                    Text("Unlock the Study Plan by purchasing Premium or entering a valid code.")
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = premiumCode,
                        onValueChange = { premiumCode = it },
                        label = { Text("Premium Code") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (viewModel.activatePremium(premiumCode)) {
                        showPremiumDialog = false
                        Toast.makeText(context, "Premium Activated!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Invalid Code", Toast.LENGTH_SHORT).show()
                    }
                }) {
                    Text("Activate", color = XFlowAccent)
                }
            },
            dismissButton = {
                TextButton(onClick = { showPremiumDialog = false }) {
                    Text("Cancel", color = XFlowTextSecondary)
                }
            },
            containerColor = XFlowSurface,
            titleContentColor = XFlowTextPrimary,
            textContentColor = XFlowTextSecondary
        )
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurface)
            .padding(16.dp)
    ) {
        Column {
            Text(title, color = XFlowTextSecondary, style = MaterialTheme.typography.bodySmall)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = XFlowTextPrimary, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun ScheduleCard(schedule: Schedule, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurface)
            .clickable(onClick = onClick)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(modifier = Modifier.weight(1f)) {
                Text(schedule.subject, color = XFlowTextPrimary, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(schedule.description, color = XFlowTextSecondary, style = MaterialTheme.typography.bodyMedium, maxLines = 2)
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Badge(text = if (schedule.isDurationMode) "${schedule.durationMinutes} min" else "${schedule.startTimeStr} - ${schedule.endTimeStr}")
                    Badge(text = if (schedule.isOnlineMode) "Online" else "Offline", isAccent = true)
                    if (schedule.isRunning) {
                        Badge(text = "Running", isAccent = true)
                    }
                }
            }
            Spacer(modifier = Modifier.width(16.dp))
            if (schedule.isOnlineMode) {
                OnlineAnimation()
            } else {
                OfflineIllustration()
            }
        }
    }
}

@Composable
fun OnlineAnimation() {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(4000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )

    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val center = androidx.compose.ui.geometry.Offset(size.width / 2, size.height / 2)
            
            drawCircle(
                color = XFlowAccent,
                radius = 8f,
                center = center
            )
            
            val radius = 20f
            val appColors = listOf(
                androidx.compose.ui.graphics.Color(0xFF4285F4),
                androidx.compose.ui.graphics.Color(0xFF34A853),
                androidx.compose.ui.graphics.Color(0xFFFBBC05),
                androidx.compose.ui.graphics.Color(0xFFEA4335)
            )
            
            for (i in 0..3) {
                val angle = Math.toRadians((rotation + i * 90).toDouble())
                val x = center.x + radius * Math.cos(angle).toFloat()
                val y = center.y + radius * Math.sin(angle).toFloat()
                
                drawRoundRect(
                    color = appColors[i],
                    topLeft = androidx.compose.ui.geometry.Offset(x - 6f, y - 6f),
                    size = androidx.compose.ui.geometry.Size(12f, 12f),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3f)
                )
            }
        }
    }
}

@Composable
fun OfflineIllustration() {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(XFlowSurfaceVariant.copy(alpha = 0.5f)),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.fillMaxSize()) {
            val bookWidth = 24f
            val bookHeight = 6f
            val startX = 8f
            var startY = size.height - 20f
            
            val bookColors = listOf(XFlowAccent, XFlowSupport, XFlowError)
            for (i in 0..2) {
                drawRoundRect(
                    color = bookColors[i % bookColors.size],
                    topLeft = androidx.compose.ui.geometry.Offset(startX, startY),
                    size = androidx.compose.ui.geometry.Size(bookWidth, bookHeight),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f)
                )
                startY -= (bookHeight + 2f)
            }
            
            val phoneWidth = 20f
            val phoneHeight = 36f
            val phoneX = size.width - phoneWidth - 10f
            val phoneY = size.height / 2 - phoneHeight / 2
            
            drawRoundRect(
                color = XFlowTextSecondary,
                topLeft = androidx.compose.ui.geometry.Offset(phoneX, phoneY),
                size = androidx.compose.ui.geometry.Size(phoneWidth, phoneHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(4f),
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2f)
            )
            drawRect(
                color = XFlowTextSecondary.copy(alpha = 0.5f),
                topLeft = androidx.compose.ui.geometry.Offset(phoneX + 3f, phoneY + 4f),
                size = androidx.compose.ui.geometry.Size(phoneWidth - 6f, phoneHeight - 8f)
            )
            drawLine(
                color = XFlowError,
                start = androidx.compose.ui.geometry.Offset(phoneX - 4f, phoneY - 4f),
                end = androidx.compose.ui.geometry.Offset(phoneX + phoneWidth + 4f, phoneY + phoneHeight + 4f),
                strokeWidth = 3f,
                cap = androidx.compose.ui.graphics.StrokeCap.Round
            )
        }
    }
}

@Composable
fun Badge(text: String, isAccent: Boolean = false) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isAccent) XFlowAccent.copy(alpha = 0.1f) else XFlowSurfaceVariant)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(text, color = if (isAccent) XFlowAccent else XFlowTextSecondary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun PremiumStudyPlanButton(isPremium: Boolean, onClick: () -> Unit) {
    val infiniteTransition = androidx.compose.animation.core.rememberInfiniteTransition()
    val offset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1000f,
        animationSpec = androidx.compose.animation.core.infiniteRepeatable(
            animation = androidx.compose.animation.core.tween(2000, easing = androidx.compose.animation.core.LinearEasing),
            repeatMode = androidx.compose.animation.core.RepeatMode.Restart
        )
    )
    val brush = androidx.compose.ui.graphics.Brush.linearGradient(
        colors = listOf(
            androidx.compose.ui.graphics.Color(0xFFFFD700),
            androidx.compose.ui.graphics.Color(0xFFFFA500),
            androidx.compose.ui.graphics.Color(0xFFFFD700)
        ),
        start = androidx.compose.ui.geometry.Offset(offset, offset),
        end = androidx.compose.ui.geometry.Offset(offset + 500f, offset + 500f)
    )

    Box(
        modifier = Modifier
            .padding(end = 8.dp)
            .height(36.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(XFlowSurface)
            .border(
                width = 2.dp,
                brush = brush,
                shape = RoundedCornerShape(18.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(Icons.Default.Add, contentDescription = "Study Plan", tint = androidx.compose.ui.graphics.Color(0xFFFFD700), modifier = Modifier.size(16.dp))
            Text("Study Plan", color = XFlowTextPrimary, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
            if (!isPremium) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(brush)
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("PRO", color = androidx.compose.ui.graphics.Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
                }
            }
        }
    }
}
